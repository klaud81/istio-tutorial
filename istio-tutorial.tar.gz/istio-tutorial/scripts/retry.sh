#!/bin/bash
istioctl create -f istiofiles/virtual-service-recommendation-v2_retry.yml -n tutorial