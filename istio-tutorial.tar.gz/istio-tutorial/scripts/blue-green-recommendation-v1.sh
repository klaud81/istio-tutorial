#!/bin/bash
istioctl replace -f istiofiles/virtual-service-recommendation-v1.yml -n tutorial
