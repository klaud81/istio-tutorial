package com.redhat.developer.demos.customer.rest;

import io.quarkus.test.junit.SubstrateTest;

@SubstrateTest
public class NativePreferenceResourceIT extends PreferenceResourceTest {

    // Execute the same tests but in native mode.
}