package com.redhat.developer.demos.preference.rest;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath("/")
public class PreferenceApplication extends Application {

    public PreferenceApplication() {
    }
}