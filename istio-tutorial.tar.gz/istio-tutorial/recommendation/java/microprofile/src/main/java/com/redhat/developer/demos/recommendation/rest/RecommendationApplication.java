package com.redhat.developer.demos.recommendation.rest;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath("/")
public class RecommendationApplication extends Application {

    public RecommendationApplication() {
    }
}