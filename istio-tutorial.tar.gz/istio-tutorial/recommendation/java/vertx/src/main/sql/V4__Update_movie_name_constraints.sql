ALTER TABLE recommendation ALTER COLUMN name DROP not null;
ALTER TABLE recommendation ALTER COLUMN movie_name SET not null;
