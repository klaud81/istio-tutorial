package com.redhat.developer.demos.customer.rest;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath("/")
public class CustomerApplication extends Application {

    public CustomerApplication() {
    }
}