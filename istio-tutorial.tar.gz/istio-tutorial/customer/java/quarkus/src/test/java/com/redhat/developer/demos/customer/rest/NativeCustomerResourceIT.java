package com.redhat.developer.demos.customer.rest;

import io.quarkus.test.junit.SubstrateTest;

@SubstrateTest
public class NativeCustomerResourceIT extends CustomerResourceTest {

    // Execute the same tests but in native mode.
}